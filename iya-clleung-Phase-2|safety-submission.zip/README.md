# SpotifyDB
67-262 project to create a database for Spotify in its startup stages
by Lisa Leung & Isaac Ahn
